import FWCore.ParameterSet.Config as cms

import math

from L1Trigger.Phase2L1ParticleFlow.l1tPFTracksFromL1Tracks_cfi import l1tPFTracksFromL1Tracks, l1tPFTracksFromL1TracksExtended
from L1Trigger.Phase2L1ParticleFlow.l1tPFClustersFromL1EGClusters_cfi import l1tPFClustersFromL1EGClusters
from L1Trigger.Phase2L1ParticleFlow.pfClustersFromCombinedCalo_cff import l1tPFClustersFromCombinedCaloHCal, l1tPFClustersFromCombinedCaloHF

from L1Trigger.Phase2L1ParticleFlow.l1TkEgAlgoEmulator_cfi import tkEgAlgoParameters,tkEgSorterParameters

from L1Trigger.Phase2L1ParticleFlow.mlAssociation_cfi import NNVtxAssociationPSet
switchOnNNAssoc = cms.bool(False)

l1tLayer1Barrel = cms.EDProducer("L1TCorrelatorLayer1Producer",
    tracks = cms.InputTag('l1tPFTracksFromL1Tracks'),
    muons = cms.InputTag('l1tSAMuonsGmt','prompt'),
    emClusters = cms.InputTag('l1tPhase2GCTBarrelToCorrelatorLayer1Emulator', 'GCTEmDigiClusters'),
    hadClusters = cms.InputTag('l1tPFClustersFromCombinedCaloHCal:calibrated'),
    # hadClusters = cms.InputTag('l1tPhase2GCTBarrelToCorrelatorLayer1Emulator', 'GCTHadDigiClusters'),
    vtxCollection = cms.InputTag("l1tVertexFinderEmulator","L1VerticesEmulation"),
    nVtx = cms.int32(1),
    emPtCut = cms.double(0.5),
    hadPtCut = cms.double(1.0),
    trkPtCut = cms.double(2.0),
    trackInputConversionAlgo = cms.string("Emulator"),
    trackInputConversionParameters = cms.PSet(
        region = cms.string("barrel"),
        slimDataFormat = cms.bool(True),
        ptLUTBits = cms.uint32(11),
        etaLUTBits = cms.uint32(10),
        etaShift = cms.uint32(15-10),
        phiBits = cms.uint32(10),
        z0Bits = cms.uint32(12),
        dEtaBarrelBits = cms.uint32(8),
        dEtaBarrelZ0PreShift = cms.uint32(2),
        dEtaBarrelZ0PostShift = cms.uint32(2),
        dPhiBarrelBits = cms.uint32(4),
        dPhiBarrelRInvPreShift = cms.uint32(4),
        dPhiBarrelRInvPostShift = cms.uint32(4),
        ),
    muonInputConversionAlgo = cms.string("Emulator"),
    gctEmInputConversionAlgo = cms.string("Emulator"),
    gctEmInputConversionParameters = cms.PSet(
        # gctEmCorrector = cms.string("L1Trigger/Phase2L1ParticleFlow/data/emcorr_barrel.root"),
        gctEmCorrector = cms.string(""),
        gctEmResol = cms.PSet(
            etaBins = cms.vdouble( 0.700,  1.200,  1.600),
            offset  = cms.vdouble( 0.873,  1.081,  1.563),
            scale   = cms.vdouble( 0.011,  0.015,  0.012),
            kind    = cms.string('calo'),
        ),
    ),
    gctHadInputConversionAlgo = cms.string("Ideal"),
    regionizerAlgo = cms.string("Ideal"),
    pfAlgo = cms.string("PFAlgo3"),
    pfAlgoParameters = cms.PSet(
        nTrack = cms.uint32(25),
        nCalo = cms.uint32(18),
        nMu = cms.uint32(2),
        nSelCalo = cms.uint32(18),
        nEmCalo = cms.uint32(12),
        nPhoton = cms.uint32(12),
        nAllNeutral = cms.uint32(25),
        trackMuDR    = cms.double(0.2), # accounts for poor resolution of standalone, and missing propagations
        trackEmDR   = cms.double(0.04), # 1 Ecal crystal size is 0.02, and ~2 cm in HGCal is ~0.007
        emCaloDR    = cms.double(0.10),    # 1 Hcal tower size is ~0.09
        trackCaloDR = cms.double(0.15),
        maxInvisiblePt = cms.double(10.0), # max allowed pt of a track with no calo energy
        tightTrackMaxInvisiblePt = cms.double(20),
        caloResolution = cms.PSet(
            etaBins = cms.vdouble( 0.700,  1.200,  1.600),
            offset  = cms.vdouble( 2.909,  2.864,  0.294),
            scale   = cms.vdouble( 0.119,  0.127,  0.442),
        ),
    ),
    puAlgo = cms.string("LinearizedPuppi"),
    puAlgoParameters = cms.PSet(
        nTrack = cms.uint32(22),
        nIn = cms.uint32(25),
        nOut = cms.uint32(25),
        nVtx = cms.uint32(1),
        nFinalSort = cms.uint32(18),
        finalSortAlgo = cms.string("Insertion"),
        dZ     = cms.double(0.5),
        dr     = cms.double(0.3),
        drMin  = cms.double(0.07),
        ptMax  = cms.double(50.),
        absEtaCuts         = cms.vdouble( ), # just one bin, so no edge needd
        ptCut             = cms.vdouble( 1.0 ),
        ptSlopes           = cms.vdouble( 0.3 ), # coefficient for pT
        ptSlopesPhoton    = cms.vdouble( 0.3 ),
        ptZeros            = cms.vdouble( 4.0 ), # ballpark pT from PU
        ptZerosPhoton     = cms.vdouble( 2.5 ),
        alphaSlopes        = cms.vdouble( 0.7 ), # coefficient for alpha
        alphaZeros         = cms.vdouble( 6.0 ), # ballpark alpha from PU
        alphaCrop         = cms.vdouble(  4  ), # max. absolute value for alpha term
        priors             = cms.vdouble( 5.0 ),
        priorsPhoton      = cms.vdouble( 1.0 ),
        useMLAssociation = switchOnNNAssoc, #Enable Association Network
        NNVtxAssociation = NNVtxAssociationPSet,
    ),
    tkEgAlgoParameters = tkEgAlgoParameters.clone(
        nTRACK = 25,
        nTRACK_EGIN = 13,
        nEMCALO_EGIN = 10,
        nEM_EGOUT = 10,
        algorithm = 4,
        trkQualityPtMin = 0.,
    ),
    tkEgSorterAlgo = cms.string("Barrel"),
    tkEgSorterParameters = tkEgSorterParameters.clone(
        nObjToSort = 10
    ),
    caloSectors = cms.VPSet(   # for Ideal regionizer only--don't include the duplicates
        cms.PSet(
            etaBoundaries = cms.vdouble(-1.5, 0, 1.5),
            phiSlices     = cms.uint32(3),
            phiZero       = cms.double(math.pi/18)
        )
    ),
    regions = cms.VPSet(
        cms.PSet(
            etaBoundaries = cms.vdouble(-1.5, -1.0, -0.5, 0.0, 0.5, 1.0, 1.5),
            phiSlices     = cms.uint32(9),
        ),
    ),
    boards = cms.VPSet(
        cms.PSet(
              regions = cms.vuint32(*[0+9*ie+i for ie in range(6) for i in range(3)])), # phi splitting
        cms.PSet(
              regions = cms.vuint32(*[3+9*ie+i for ie in range(6) for i in range(3)])), # phi splitting
        cms.PSet(
              regions = cms.vuint32(*[6+9*ie+i for ie in range(6) for i in range(3)])), # phi splitting
    ),
)

l1tLayer1BarrelExtended = l1tLayer1Barrel.clone(tracks = cms.InputTag('l1tPFTracksFromL1TracksExtended'))

_hgcalSectors = cms.VPSet(
    cms.PSet(
        etaBoundaries = cms.vdouble(-3.0, -1.5),
        phiSlices     = cms.uint32(3),
        phiZero       = cms.double(math.pi/2) # The edge of the 0th HGCal sectors is at 30 deg, the center at 30+120/2 = 90 = pi/2
    ),
    cms.PSet(
        etaBoundaries = cms.vdouble(+1.5, +3.0),
        phiSlices     = cms.uint32(3),
        phiZero       = cms.double(math.pi/2) # As above
    )

)

l1tLayer1HGCal = cms.EDProducer("L1TCorrelatorLayer1Producer",
    tracks = cms.InputTag('l1tPFTracksFromL1Tracks'),
    muons = cms.InputTag('l1tSAMuonsGmt','prompt'),
    emClusters = cms.InputTag(""), # the em clusters are "intercepted" from the had ones in the regionizer
    hadClusters = cms.InputTag("l1tHGCalBackEndLayer2Producer","HGCalBackendLayer2Processor3DClustering"),
    vtxCollection = cms.InputTag("l1tVertexFinderEmulator","L1VerticesEmulation"),
    nVtx = cms.int32(1),
    emPtCut = cms.double(-1.),
    hadPtCut = cms.double(-1.),
    trkPtCut = cms.double(2.0),
    trackInputConversionAlgo = cms.string("Emulator"),
    trackInputConversionParameters = cms.PSet(
        region = cms.string("endcap"),
        slimDataFormat = cms.bool(False),
        ptLUTBits = cms.uint32(11),
        etaLUTBits = cms.uint32(11),
        etaShift = cms.uint32(15-11),
        etaPostOffs = cms.int32(150),
        phiBits = cms.uint32(10),
        z0Bits = cms.uint32(12),
        dEtaHGCalBits = cms.uint32(10),
        dEtaHGCalZ0PreShift = cms.uint32(2),
        dEtaHGCalRInvPreShift = cms.uint32(6),
        dEtaHGCalLUTBits = cms.uint32(10),
        dEtaHGCalLUTShift = cms.uint32(2),
        dPhiHGCalBits = cms.uint32(4),
        dPhiHGCalZ0PreShift = cms.uint32(4),
        dPhiHGCalZ0PostShift = cms.uint32(6),
        dPhiHGCalRInvShift = cms.uint32(4),
        dPhiHGCalTanlInvShift = cms.uint32(22),
        dPhiHGCalTanlLUTBits = cms.uint32(10),
        ),
    muonInputConversionAlgo = cms.string("Emulator"),
    hgcalInputConversionAlgo = cms.string("Emulator"),
    hgcalInputConversionParameters = cms.PSet(
        slim = cms.bool(False),
        multiclass_id = cms.PSet(
            model = cms.string("L1Trigger/Phase2L1ParticleFlow/data/multiclassID/multiclass_EE.json"),
            wp_eta = cms.vdouble(2.4), # eta bin edges for the WPs
            wps = cms.VPSet(
                cms.PSet(
                    wp_pt = cms.vdouble(20),
                    wp_PU = cms.vdouble(0.33462133, 0.25283374),
                    wp_Pi = cms.vdouble(0.26773010, 0.03898286),
                    wp_PFEm = cms.vdouble(0.29812516, 0.42790125),
                    wp_EgEm = cms.vdouble(0.29812516, 0.42790125),
                    wp_EgEm_tight = cms.vdouble(0.60654651, 0.42790125),
                ),
                cms.PSet(
                    wp_pt = cms.vdouble(20),
                    wp_PU = cms.vdouble(0.42100209, 0.52275714),
                    wp_Pi = cms.vdouble(0.12800815, 0.20509825),
                    wp_PFEm = cms.vdouble(0.35924579, 0.67921004),
                    wp_EgEm = cms.vdouble(0.35924579, 0.67921004),
                    wp_EgEm_tight = cms.vdouble(0.76317512, 0.67921004),
                )
            ),
        ),
        corrector = cms.string("L1Trigger/Phase2L1ParticleFlow/data/hadcorr_HGCal3D_TC.root"),
        correctorEmfMax = cms.double(1.125),
        emulateCorrections = cms.bool(False), # NOTE: should switch this on for FW bit-wise agreement!
        emInterpScenario = cms.string("allKeepHad"), # for all clusters, use EM intepretation to redefine the EM part of the energy
    ),
    regionizerAlgo = cms.string("Multififo"),
    regionizerAlgoParameters = cms.PSet(
        useAlsoVtxCoords = cms.bool(True),
        nEndcaps = cms.uint32(2),
        nClocks = cms.uint32(54),
        nTkLinks = cms.uint32(2),
        nCaloLinks = cms.uint32(3),
        nTrack = cms.uint32(30),
        nCalo = cms.uint32(20),
        nEmCalo = cms.uint32(10),
        nMu = cms.uint32(4),
        egInterceptMode = cms.PSet(
            afterFifo = cms.bool(True),
            emIDMask = cms.uint32(0x1E),
            nHADCALO_IN = cms.uint32(20),
            nEMCALO_OUT = cms.uint32(10),
            )
        ),
    pfAlgo = cms.string("PFAlgo2HGC"),
    pfAlgoParameters = cms.PSet(
        nTrack = cms.uint32(30),
        nCalo = cms.uint32(20),
        nMu = cms.uint32(4),
        nSelCalo = cms.uint32(20),
        trackMuDR    = cms.double(0.2), # accounts for poor resolution of standalone, and missing propagations
        trackCaloDR = cms.double(0.1),
        maxInvisiblePt = cms.double(10.0), # max allowed pt of a track with no calo energy
        tightTrackMaxInvisiblePt = cms.double(20),
        caloResolution = cms.PSet(
            etaBins = cms.vdouble( 1.700,  1.900,  2.200,  2.500,  2.800,  2.900),
            offset  = cms.vdouble( 1.793,  1.827,  2.363,  2.538,  2.812,  2.642),
            scale   = cms.vdouble( 0.138,  0.137,  0.124,  0.115,  0.106,  0.121),
        ),
    ),
    puAlgo = cms.string("LinearizedPuppi"),
    puAlgoParameters = cms.PSet(
        nTrack = cms.uint32(30),
        nIn = cms.uint32(20),
        nOut = cms.uint32(20),
        nVtx        = cms.uint32(1),
        nFinalSort = cms.uint32(18),
        finalSortAlgo = cms.string("FoldedHybrid"),
        dZ     = cms.double(1.33),
        dr     = cms.double(0.3),
        drMin  = cms.double(0.04),
        ptMax  = cms.double(50.),
        absEtaCuts         = cms.vdouble( 2.0 ), # two bins in the tracker (different eta); give only the one boundary between them
        ptCut             = cms.vdouble( 1.0, 2.0 ),
        ptSlopes           = cms.vdouble( 0.3, 0.3 ), # coefficient for pT
        ptSlopesPhoton    = cms.vdouble( 0.4, 0.4 ), #When e/g ID not applied, use: cms.vdouble( 0.3, 0.3, 0.3 ),
        ptZeros            = cms.vdouble( 5.0, 7.0 ), # ballpark pT from PU
        ptZerosPhoton     = cms.vdouble( 3.0, 4.0 ),
        alphaSlopes        = cms.vdouble( 1.5, 1.5 ),
        alphaZeros         = cms.vdouble( 6.0, 6.0 ),
        alphaCrop         = cms.vdouble(  3 ,  3  ), # max. absolute value for alpha term
        priors             = cms.vdouble( 5.0, 5.0 ),
        priorsPhoton      = cms.vdouble( 1.5, 1.5 ), #When e/g ID not applied, use: cms.vdouble( 3.5, 3.5, 7.0 ),
        useMLAssociation = switchOnNNAssoc, #Enable Association Network
        NNVtxAssociation = NNVtxAssociationPSet,
    ),
    tkEgAlgoParameters = tkEgAlgoParameters.clone(
        nTRACK = 30,
        nTRACK_EGIN = 10,
        nEMCALO_EGIN = 10,
        nEM_EGOUT = 5,
        doBremRecovery = True,
        doEndcapHwQual = True,
        writeBeforeBremRecovery = False,
        writeEGSta = True,
        algorithm = 1,
        trkQualityPtMin = 0., # This should be 10 GeV when doCompositeTkEle = False
        # compositeParametersTkEle=cms.PSet(
        #     # NOTE: conifer BDT score is log(p/1-p)
        #     # the working points are cuts on BDT output logits [log(p/1-p)]/4 (range -1 to 1 to match the FW dataformat)
        #     loose_wp=cms.double(-9999),
        #     tight_wp=cms.double(0.0527344),
        #     model=cms.string("L1Trigger/Phase2L1ParticleFlow/data/egamma/compositeID_EE_v1.json")
        # ),
        ), 
    tkEgSorterAlgo = cms.string("Endcap"),
    tkEgSorterParameters = tkEgSorterParameters.clone(
        nObjToSort = 5
    ),
    caloSectors = _hgcalSectors,
    regions = cms.VPSet(
        cms.PSet(
            etaBoundaries = cms.vdouble(-2.5, -1.5),
            phiSlices     = cms.uint32(9),
        ),
        cms.PSet(
            etaBoundaries = cms.vdouble(+1.5, +2.5),
            phiSlices     = cms.uint32(9),
        )

    ),
    boards = cms.VPSet(
        cms.PSet(
            regions = cms.vuint32(range(0, 9))),
        cms.PSet(
            regions = cms.vuint32(range(9, 18))),
    ),
)


l1tLayer1HGCalExtended = l1tLayer1HGCal.clone(tracks = ('l1tPFTracksFromL1TracksExtended'))

l1tLayer1HGCalElliptic = l1tLayer1HGCal.clone(
    tkEgAlgoParameters = l1tLayer1HGCal.tkEgAlgoParameters.clone(
        algorithm = 0,
        trkQualityPtMin = 10.)
)

l1tLayer1HGCalNoTK = cms.EDProducer("L1TCorrelatorLayer1Producer",
    muons = cms.InputTag('l1tSAMuonsGmt','prompt'),
    emClusters = cms.InputTag(""),
    hadClusters = cms.InputTag("l1tHGCalBackEndLayer2Producer","HGCalBackendLayer2Processor3DClustering"),
    vtxCollection = cms.InputTag("l1tVertexFinderEmulator","L1VerticesEmulation"),
    nVtx = cms.int32(1),
    emPtCut = cms.double(-1),
    hadPtCut = cms.double(-1),
    trkPtCut = cms.double(2.0),
    muonInputConversionAlgo = cms.string("Emulator"),
    hgcalInputConversionAlgo = cms.string("Emulator"),
    hgcalInputConversionParameters = cms.PSet(
        slim = cms.bool(True),
        multiclass_id = cms.PSet(
            model = cms.string("L1Trigger/Phase2L1ParticleFlow/data/multiclassID/multiclass_EE.json"),
            wp_eta = cms.vdouble(2.4), # eta bin edges for the WPs
            wps = cms.VPSet(
                cms.PSet(
                    wp_pt = cms.vdouble(20),
                    wp_PU = cms.vdouble(0.33462133, 0.25283374),
                    wp_Pi = cms.vdouble(0.26773010, 0.03898286),
                    wp_PFEm = cms.vdouble(0.29812516, 0.42790125),
                    wp_EgEm = cms.vdouble(0.29812516, 0.42790125),
                    wp_EgEm_tight = cms.vdouble(0.60654651, 0.42790125),
                ),
                cms.PSet(
                    wp_pt = cms.vdouble(20),
                    wp_PU = cms.vdouble(0.42100209, 0.52275714),
                    wp_Pi = cms.vdouble(0.12800815, 0.20509825),
                    wp_PFEm = cms.vdouble(0.35924579, 0.67921004),
                    wp_EgEm = cms.vdouble(0.35924579, 0.67921004),
                    wp_EgEm_tight = cms.vdouble(0.76317512, 0.67921004),
                )
            ),
        ),
        corrector = cms.string("L1Trigger/Phase2L1ParticleFlow/data/hadcorr_HGCal3D_TC.root"),
        correctorEmfMax = cms.double(1.125),
        emulateCorrections = cms.bool(False), # NOTE: should switch this on for FW bit-wise agreement!
        emInterpScenario = cms.string("allKeepHad"), # for all clusters, use EM intepretation to redefine the EM part of the energy
    ),
    regionizerAlgo = cms.string("Multififo"),
    regionizerAlgoParameters = cms.PSet(
        useAlsoVtxCoords = cms.bool(True),
        nEndcaps = cms.uint32(2),
        nClocks = cms.uint32(54),
        nTkLinks = cms.uint32(0),
        nCaloLinks = cms.uint32(3),
        nTrack = cms.uint32(0),
        nCalo = cms.uint32(12),
        nEmCalo = cms.uint32(12),
        nMu = cms.uint32(4),
        egInterceptMode = cms.PSet(
            afterFifo = cms.bool(True),
            emIDMask = cms.uint32(0x1E),
            nHADCALO_IN = cms.uint32(12),
            nEMCALO_OUT = cms.uint32(12),
            )
        ),
    pfAlgo = cms.string("PFAlgoDummy"),
    pfAlgoParameters = cms.PSet(
        nCalo = cms.uint32(12),
        nMu = cms.uint32(4), # unused
    ),
    puAlgo = cms.string("LinearizedPuppi"),
    puAlgoParameters = cms.PSet(
        nTrack = cms.uint32(0),  # unused
        nIn = cms.uint32(12),
        nOut = cms.uint32(12),
        nFinalSort = cms.uint32(12), # to be tuned
        finalSortAlgo = cms.string("Hybrid"),
        nVtx = cms.uint32(1),
        dZ     = cms.double(1.33),
        dr     = cms.double(0.3),
        drMin  = cms.double(0.04),
        ptMax  = cms.double(50.),
        absEtaCuts         = cms.vdouble( ), # just one bin
        ptCut             = cms.vdouble( 4.0 ),
        ptSlopes           = cms.vdouble( 0.3 ), # coefficient for pT
        ptSlopesPhoton    = cms.vdouble( 0.4 ), #When e/g ID not applied, use: cms.vdouble( 0.3, 0.3, 0.3 ),
        ptZeros            = cms.vdouble( 9.0 ), # ballpark pT from PU
        ptZerosPhoton     = cms.vdouble( 5.0 ),
        alphaSlopes        = cms.vdouble( 2.2 ),
        alphaZeros         = cms.vdouble( 9.0 ),
        alphaCrop         = cms.vdouble(  4  ), # max. absolute value for alpha term
        priors             = cms.vdouble( 7.0 ),
        priorsPhoton      = cms.vdouble( 5.0 ), #When e/g ID not applied, use: cms.vdouble( 3.5, 3.5, 7.0 ),
        useMLAssociation = switchOnNNAssoc, #Enable Association Network
        NNVtxAssociation = NNVtxAssociationPSet,
    ),
    tkEgAlgoParameters = tkEgAlgoParameters.clone(
        nTRACK = 30,
        nTRACK_EGIN = 10,
        nEMCALO_EGIN = 10,
        nEM_EGOUT = 5,
        doBremRecovery = True,
        doEndcapHwQual = True,
        writeBeforeBremRecovery = False,
        writeEGSta = True),
    tkEgSorterAlgo = cms.string("Endcap"),
    tkEgSorterParameters = tkEgSorterParameters.clone(
        nObjToSort = 5
    ),
    caloSectors = _hgcalSectors,
    regions = cms.VPSet(
        cms.PSet(
            etaBoundaries = cms.vdouble(-3.0, -2.5),
            phiSlices     = cms.uint32(9),
        ),
        cms.PSet(
            etaBoundaries = cms.vdouble(+2.5, +3.0),
            phiSlices     = cms.uint32(9),
        )

    ),
    boards = cms.VPSet(
        cms.PSet(regions = cms.vuint32(range(0,18))),
    ),
)

l1tLayer1HF = cms.EDProducer("L1TCorrelatorLayer1Producer",
    muons = cms.InputTag('l1tSAMuonsGmt','prompt'),
    emClusters = cms.InputTag(''),
    hadClusters = cms.InputTag('l1tPFClustersFromCombinedCaloHF:calibrated'),
    gctHadInputConversionAlgo = cms.string("Ideal"),
    vtxCollection = cms.InputTag("l1tVertexFinderEmulator","L1VerticesEmulation"),
    nVtx = cms.int32(1),
    emPtCut = cms.double(0.5),
    hadPtCut = cms.double(15.0),
    trkPtCut = cms.double(2.0),
    pfAlgo = cms.string("PFAlgoDummy"),
    pfAlgoParameters = cms.PSet(
        nCalo = cms.uint32(18),
        nMu = cms.uint32(4), # unused
        debug = cms.untracked.bool(False)
    ),
    puAlgo = cms.string("LinearizedPuppi"),
    puAlgoParameters = cms.PSet(
        nTrack = cms.uint32(0), # unused
        nIn = cms.uint32(18),
        nOut = cms.uint32(18),
        nVtx = cms.uint32(1),
        nFinalSort = cms.uint32(10), # to be tuned
        finalSortAlgo = cms.string("Insertion"),
        dZ     = cms.double(1.33),
        dr     = cms.double(0.3),
        drMin  = cms.double(0.1),
        ptMax  = cms.double(100.),
        absEtaCuts         = cms.vdouble(   ), # just one bin
        ptCut             = cms.vdouble( 10.0  ),
        ptSlopes           = cms.vdouble(  0.25 ),
        ptSlopesPhoton    = cms.vdouble(  0.25 ),
        ptZeros            = cms.vdouble( 14.0  ),
        ptZerosPhoton     = cms.vdouble( 14.0  ),
        alphaSlopes        = cms.vdouble(  0.6  ),
        alphaZeros         = cms.vdouble(  9.0  ),
        alphaCrop         = cms.vdouble(   4   ),
        priors             = cms.vdouble(  6.0  ),
        priorsPhoton      = cms.vdouble(  6.0  ),
        debug = cms.untracked.bool(False),
        useMLAssociation = switchOnNNAssoc, #Enable Association Network
        NNVtxAssociation = NNVtxAssociationPSet,
    ),
    tkEgAlgoParameters = tkEgAlgoParameters.clone(
        nTRACK = 5,           # to be defined
        nTRACK_EGIN = 5,          # to be defined
        nEMCALO_EGIN = 5,  # to be defined
        nEM_EGOUT = 5,        # to be defined
        doBremRecovery = True,
        writeEGSta = True),
    tkEgSorterAlgo = cms.string("Endcap"),
    tkEgSorterParameters = tkEgSorterParameters.clone(),
    caloSectors = cms.VPSet(
        cms.PSet(
            etaBoundaries = cms.vdouble(-5.5, -3.0),
            phiSlices     = cms.uint32(9),
        ),
        cms.PSet(
            etaBoundaries = cms.vdouble(+3.0, +5.5),
            phiSlices     = cms.uint32(9),
        )
    ),
    regions = cms.VPSet(
        cms.PSet(
            etaBoundaries = cms.vdouble(-5.5, -3.0),
            phiSlices     = cms.uint32(9),
        ),
        cms.PSet(
            etaBoundaries = cms.vdouble(+3.0, +5.5),
            phiSlices     = cms.uint32(9),
        )
    ),
    boards = cms.VPSet(),
)


l1tLayer1 = cms.EDProducer("L1TPFCandMultiMerger",
    pfProducers = cms.VInputTag(
        cms.InputTag("l1tLayer1Barrel"),
        cms.InputTag("l1tLayer1HGCal"),
        cms.InputTag("l1tLayer1HGCalNoTK"),
        cms.InputTag("l1tLayer1HF")
    ),

)


l1tLayer1Extended = l1tLayer1.clone(
    pfProducers = [ ("l1tLayer1BarrelExtended"), ("l1tLayer1HGCalExtended"),
        ("l1tLayer1HGCalNoTK"),("l1tLayer1HF")]
)

l1tLayer1EG = cms.EDProducer(
    "L1TEGMultiMerger",
    tkElectrons = cms.VPSet(
        cms.PSet(
            instance = cms.string("L1TkEleEE"),
            pfProducers = cms.VInputTag(
                cms.InputTag("l1tLayer1HGCal", 'L1TkEle')
            )
        ),
        cms.PSet(
            instance = cms.string("L1TkEleEB"),
            pfProducers = cms.VInputTag(
                cms.InputTag("l1tLayer1Barrel", 'L1TkEle')
            )
        )
    ),
    tkEms = cms.VPSet(
        cms.PSet(
            instance = cms.string("L1TkEmEE"),
            pfProducers = cms.VInputTag(
                cms.InputTag("l1tLayer1HGCal", 'L1TkEm'),
                cms.InputTag("l1tLayer1HGCalNoTK", 'L1TkEm')
            )
        ),
        cms.PSet(
            instance = cms.string("L1TkEmEB"),
            pfProducers = cms.VInputTag(
                cms.InputTag("l1tLayer1Barrel", 'L1TkEm')
            )
        )
    ),
    tkEgs = cms.VPSet(
        cms.PSet(
            instance = cms.string("L1EgEE"),
            pfProducers = cms.VInputTag(
                cms.InputTag("l1tLayer1HGCal", 'L1Eg'),
                cms.InputTag("l1tLayer1HGCalNoTK", 'L1Eg')
            )
        )
    )
)

l1tLayer1EGElliptic = cms.EDProducer(
    "L1TEGMultiMerger",
    tkElectrons = cms.VPSet(
        cms.PSet(
            instance = cms.string("L1TkEleEE"),
            pfProducers = cms.VInputTag(
                cms.InputTag("l1tLayer1HGCalElliptic", 'L1TkEle')
            )
        ),
        cms.PSet(
            instance = cms.string("L1TkEleEB"),
            pfProducers = cms.VInputTag(
                cms.InputTag("l1tLayer1Barrel", 'L1TkEle')
            )
        )
    ),
    tkEms = cms.VPSet(
        cms.PSet(
            instance = cms.string("L1TkEmEE"),
            pfProducers = cms.VInputTag(
                cms.InputTag("l1tLayer1HGCalElliptic", 'L1TkEm'),
                cms.InputTag("l1tLayer1HGCalNoTK", 'L1TkEm')
            )
        ),
        cms.PSet(
            instance = cms.string("L1TkEmEB"),
            pfProducers = cms.VInputTag(
                cms.InputTag("l1tLayer1Barrel", 'L1TkEm')
            )
        )
    ),
    tkEgs = cms.VPSet(
        cms.PSet(
            instance = cms.string("L1EgEE"),
            pfProducers = cms.VInputTag(
                cms.InputTag("l1tLayer1HGCalElliptic", 'L1Eg'),
                cms.InputTag("l1tLayer1HGCalNoTK", 'L1Eg')
            )
        )
    )
)



L1TLayer1TaskInputsTask = cms.Task(
    l1tPFClustersFromL1EGClusters,
    l1tPFClustersFromCombinedCaloHCal,
    l1tPFClustersFromCombinedCaloHF,
    l1tPFTracksFromL1Tracks,
    l1tPFTracksFromL1TracksExtended
)

L1TLayer1Task = cms.Task(
     l1tLayer1Barrel,
     l1tLayer1BarrelExtended,
     l1tLayer1HGCal,
     l1tLayer1HGCalExtended,
     l1tLayer1HGCalNoTK,
     l1tLayer1HF,
     l1tLayer1,
     l1tLayer1Extended,
     l1tLayer1HGCalElliptic,
     l1tLayer1EG,
     l1tLayer1EGElliptic
)
