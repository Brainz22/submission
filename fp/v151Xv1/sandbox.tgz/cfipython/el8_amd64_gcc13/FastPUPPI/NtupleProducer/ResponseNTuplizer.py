import FWCore.ParameterSet.Config as cms

def ResponseNTuplizer(*args, **kwargs):
  mod = cms.EDAnalyzer('ResponseNTuplizer',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
