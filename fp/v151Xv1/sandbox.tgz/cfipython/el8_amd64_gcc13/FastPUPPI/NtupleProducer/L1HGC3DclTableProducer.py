import FWCore.ParameterSet.Config as cms

def L1HGC3DclTableProducer(*args, **kwargs):
  mod = cms.EDProducer('L1HGC3DclTableProducer',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
