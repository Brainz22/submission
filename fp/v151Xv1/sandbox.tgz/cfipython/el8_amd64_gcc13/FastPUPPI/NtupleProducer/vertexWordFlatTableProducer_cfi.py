import FWCore.ParameterSet.Config as cms

from .VertexWordFlatTableProducer import VertexWordFlatTableProducer

vertexWordFlatTableProducer = VertexWordFlatTableProducer()
