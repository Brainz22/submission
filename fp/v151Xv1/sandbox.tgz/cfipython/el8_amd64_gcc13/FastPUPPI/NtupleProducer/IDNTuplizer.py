import FWCore.ParameterSet.Config as cms

def IDNTuplizer(*args, **kwargs):
  mod = cms.EDAnalyzer('IDNTuplizer',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
