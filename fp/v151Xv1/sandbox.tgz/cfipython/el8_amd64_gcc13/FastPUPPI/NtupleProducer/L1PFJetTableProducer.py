import FWCore.ParameterSet.Config as cms

def L1PFJetTableProducer(*args, **kwargs):
  mod = cms.EDProducer('L1PFJetTableProducer',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
