import FWCore.ParameterSet.Config as cms

def L1CTL2EgammaBinaryDumper(*args, **kwargs):
  mod = cms.EDAnalyzer('L1CTL2EgammaBinaryDumper',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
