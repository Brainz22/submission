import FWCore.ParameterSet.Config as cms

def TauNTuplizer(*args, **kwargs):
  mod = cms.EDAnalyzer('TauNTuplizer',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
