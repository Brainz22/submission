__path__.append('/cvmfs/cms.cern.ch/el8_amd64_gcc13/cms/cmssw/CMSSW_17_0_0_pre1/python/L1Trigger')
